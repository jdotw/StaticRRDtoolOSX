
1 September 2010: Philippe Hausler updated the xcode project to work
with libpng-1.4.x and added iOS targets for simulator and device.
